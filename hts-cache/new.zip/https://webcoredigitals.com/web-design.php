<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="assets/images/favicon.webp">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css" />
    <link rel="stylesheet" href="https://cdn.rawgit.com/michalsnik/aos/1.0.1/dist/aos.css" />
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.0/dist/aos.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">
    <title>Webcore Digitals</title>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-5ZDDX47Q');</script>
    <!-- End Google Tag Manager -->
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5ZDDX47Q"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <header class="header-row" id="header-row">
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <!-- Logo -->
                <a class="navbar-brand" href="/">
                    <img src="assets/images/logo.png" alt="logo">
                </a>
                <!-- Navbar toggle -->
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <!-- Collapse -->
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <!-- Nav -->
                    <div class="navbar-nav mx-lg-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="/">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about-us">About Us</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="services" role="button">
                                Services
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="logo-and-branding">Logo and Brand Visibility</a></li>
                                <li><a class="dropdown-item" href="web-design">Web Design and Development</a></li>
                                <li><a class="dropdown-item" href="animation">Animation</a></li>
                                <li><a class="dropdown-item" href="mobile-application">Mobile Application Development</a></li>
                                <li><a class="dropdown-item" href="seo">Search Engine Optimization</a></li>
                                <li><a class="dropdown-item" href="illustration-and-art">Illustration and Art</a></li>
                                <li><a class="dropdown-item" href="content-marketing">Content Marketing</a></li>
                                <li><a class="dropdown-item" href="bpo-services">BPO Services</a></li>
                                <li><a class="dropdown-item" href="video-animation">Video Animation</a></li>
                                <li><a class="dropdown-item" href="digital-marketing">Digital Marketing</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="portfolio">Portfolio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="packages">Packages</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="blog">Blogs</a>
                        </li>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact-us">Contact Us</a>
                        </li>
                    </div>
                    <!-- Right navigation -->
                    <div class="d-flex align-items-lg-center">
                        <a href="javascript:;" class="btn btn-sm btn-primary w-full w-lg-auto w-btn various">Get a Quote</a>
                    </div>
                </div>
            </div>
        </nav>
    </header>    <section class="inner-banner-row">
        <div class="container">
            <div class="inner-banner-sec" data-aos="fade-up">
                <h1>Your Website Should <span>Work as Hard</span> as You Do</h1>
                <p>We don’t just build websites—we create fast, mobile-ready, conversion-driven experiences designed to grow your business. At Web Core Digital, every site is crafted with clean code, smart UX, and SEO baked in from day one. </p>
            </div>
        </div>
    </section>
    <section class="services-page-row service-about-row">
        <div class="container">
            <div class="services-head service-inner-head inner-heading text-center" data-aos="slide-up">
                <img src="assets/images/website-heading.png" alt="service heading">
            </div>
            <div class="row align-items-center">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="w-head w-sec services-page-sec" data-aos="fade-right">
                        <h3>Web Design and Development</h3>
                        <h2>Built to Perform, <span>Designed</span> to Convert</h2>
                        <p>A first impression lasts, and your virtual shop window is your website. We design clean, usable websites with quick loads, clear appearance across all devices, and tailored to your business interests. It doesn't matter whether you need a service-based site or a complete e-commerce platform; we can combine design, technology to drive results.</p>
                        <a href="javascript:;"><button class="btn btn-primary w-btn">learn more</button></a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="services-details-sec" data-aos="fade-left">
                        <img src="assets/images/web-about.png" alt="service image">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="services-portfolio-slider-row services-single-portfolo-row">
        <div class="container-fluid">
            <div class="w-head w-sec service-port-head text-center" data-aos="fade-up">
                <h3>Complete Web Solutions</h3>
                <h2>Custom <span>Web Design</span> That Speaks Your Brand</h2>
                <p>We develop fast, responsive websites unique to your brand that not only impress but also win your customers. We make your digital dreams a reality, regardless of whether you are a startup or a small or a large business.  </p>
            </div>
            <div class="services-portfolio-slider-sec" data-aos="fade-down">
                <img src="assets/images/showcase-webs.png" alt="website showcase">
            </div>
        </div>
    </section>
    <section class="services-page-row service-web-details-row">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="services-page-sec" data-aos="fade-right">
                        <img src="assets/images/web-offer-img.png" alt="service image">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="w-head w-sec services-page-sec" data-aos="fade-left">
                        <h3>What We Offer</h3>
                        <h2>What’s<span> Included in</span> Your Brand Package</h2>
                        <p>Professional design meets performance for a website that truly works for you.</p>
                        <ul>
                            <li>Custom Design (No Templates)</li>
                            <li>Responsive Development (Mobile + Desktop)</li>
                            <li>SEO-Friendly Structure & Speed Optimisation</li>
                            <li>Home, About, Services + Contact Pages (or Custom Flow)</li>
                            <li>Secure Contact Forms & Integrations</li>
                            <li>Basic Analytics Setup (Google or Meta Pixel)</li>
                            <li>Optional Blog or Ecommerce Functionality</li>
                        </ul>
                        <a href="javascript:;"><button class="btn btn-primary w-btn">learn more</button></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
        <section class="portfolio-row">
        <div class="container-fluid">
            <div class="portfolio-head text-center" data-aos="slide-up">
                <h3>our portfolio</h3>
                <h2>portfolio</h2>
            </div>
            <div class="portfolio-tabs">
                <ul class="nav nav-pills justify-content-center" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-web-tab" data-bs-toggle="pill" data-bs-target="#pills-web" type="button" role="tab" aria-controls="pills-web" aria-selected="false">Web Design</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-logo-tab" data-bs-toggle="pill" data-bs-target="#pills-logo" type="button" role="tab" aria-controls="pills-logo" aria-selected="false">Logo & Brand Identity</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-video-tab" data-bs-toggle="pill" data-bs-target="#pills-video" type="button" role="tab" aria-controls="pills-video" aria-selected="false">Video Animation</button>
                    </li>
                </ul>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-web" role="tabpanel" aria-labelledby="pills-web-tab">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-right">
                                    <a data-fancybox="" href="assets/images/portfolio/website/01.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/01.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-down">
                                    <a data-fancybox="" href="assets/images/portfolio/website/02.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/02.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-left">
                                    <a data-fancybox="" href="assets/images/portfolio/website/03.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/03.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-right">
                                    <a data-fancybox="" href="assets/images/portfolio/website/04.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/04.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-up">
                                    <a data-fancybox="" href="assets/images/portfolio/website/05.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/05.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-left">
                                    <a data-fancybox="" href="assets/images/portfolio/website/06.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/06.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-right">
                                    <a data-fancybox="" href="assets/images/portfolio/website/07.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/07.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-down">
                                    <a data-fancybox="" href="assets/images/portfolio/website/08.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/08.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-logo" role="tabpanel" aria-labelledby="pills-logo-tab">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-right">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/01.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/01.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-down">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/02.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/02.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-left">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/03.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/03.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-right">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/04.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/04.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-up">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/05.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/05.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-left">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/06.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/06.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-right">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/07.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/07.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-left">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/08.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/08.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-video" role="tabpanel" aria-labelledby="pills-video-tab">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="portfolio-sec" data-aos="fade-right">
                                    <a data-fancybox="" href="assets/images/portfolio/video/video1.mp4" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/video/video1-thumb.jpg" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="portfolio-sec" data-aos="fade-down">
                                    <a data-fancybox="" href="assets/images/portfolio/video/video2.mp4" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/video/video2-thumb.jpg" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="portfolio-sec" data-aos="fade-left">
                                    <a data-fancybox="" href="assets/images/portfolio/video/video3.mp4" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/video/video3-thumb.jpg" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="video-btn">
                <a href="portfolio.php"><button class="btn btn-primary w-btn">learn more</button></a>
                <a href="javascript:;"><button class="btn btn-primary w-btn w-btn2"><i class="fa-regular fa-envelope"></i> live chat</button></a>
            </div>
        </div>
    </section>    <footer class="footer-row">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-5">
                    <div class="footer-cont">
                        <img src="assets/images/footer-logo.png" alt="footer logo">
                        <p>Web Core Digital builds fast, high-performing websites that drive traffic and conversions.</p>
                        <a href="contact-us.php"><button class="btn btn-primary w-btn">book a call</button></a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-2">
                    <div class="footer-links">
                        <h6>Quick links</h6>
                        <ul>
                            <li><a href="/">Home</a></li>
                            <li><a href="about-us">About Us</a></li>
                            <li><a href="services">Services</a></li>
                            <li><a href="portfolio">Portfolio</a></li>
                            <li><a href="packages">Pricing</a></li>
                            <li><a href="contact-us">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-2">
                    <div class="footer-links">
                        <h6>SERVICES</h6>
                        <ul>
                            <li><a href="web-design">web design</a></li>
                            <li><a href="logo-and-branding">logo design</a></li>
                            <li><a href="mobile-application">app development </a></li>
                            <li><a href="animation">video animation</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                    <div class="footer-details">
                        <h6>Contact Info</h6>
                        <ul>
                            <li><a href="tel:315-753-8424">(315) 753-8424</a></li>
                            <li><a href="mailto:support@webcoredigitals.com">support@webcoredigitals.com</a></li>
                             <li><a href="javascript:;">85-49 Parsons Blvd Jamaica, NY 11432, USA</a></li> 
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-row">
            <div class="container-fluid">
                <div class="copyright-sec">
                    <p>Copyright © Webcore Digitals 2026. All rights reserved.</p>
                    <ul>
                        <li><a href="termsandconditions">Terms & Conditions</a></li>
                        <li><a href="privacy-policy">privacy policy</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="popup_form">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
                        <h3 class="title">Get Started</h3>
                        <form action="send_data.php" method="POST" name="popup-validate-form" id="popup_lead_data">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form_field">
                                        <input type="text" name="order_fullname" id="order_fullname" class="c_field" placeholder="Name*" required>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form_field">
                                        <input type="email" class="c_field" name="order_email" id="order_email" placeholder="Email Address*" required >
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form_field">
                                        <input type="text" name="number" id="phonePopup" class="c_field" placeholder="Phone Number*" required >
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form_field">
                                        <textarea class="c_field" name="order_description" id="order_description" rows="5" placeholder="Tell us about your website requirements"></textarea>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <button type="submit" class="btn btn-sm btn-primary w-btn">Get a Quote</button>
                                    <input type="hidden" name="cip" value="205.164.147.148">										
                                    <input type="hidden" id="location" name="locationURL" value="https://webcoredigitals.com/web-design.php">
                                    <input type="hidden" name="order_package_name" value="Website Basic Package - $199" class="package_name" id="package_name">
                                    <input type="hidden" name="order-from" value="1">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.rawgit.com/michalsnik/aos/1.0.1/dist/aos.js"></script>
    <script src="https://unpkg.com/aos@2.3.0/dist/aos.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.0/js/fontawesome.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- Start of ultradigitalsolution Zendesk Widget script -->
    <script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=cb0f074a-fed2-429d-953d-ab53aee123aa"> </script>
    <!-- End of ultradigitalsolution Zendesk Widget script -->
        <script>
            zE(function() {
                $zopim(function() {
                    $zopim.livechat.setOnUnreadMsgs(unread);
            
                    function unread(number) {
                        if (number >= 1) {
                            $zopim.livechat.window.show();
                        }
                    }
                });
            });
        </script>
        <script>
            window.addEventListener("load", function () {
                setTimeout(function () {
                    if (window.zE) {
                        zE('webWidget', 'open');
                    }
                }, 30000); // 30 seconds = 30000 milliseconds
            });
        </script>
        <script>
         $(document).ready(function () {
            // Show after 5 seconds
            setTimeout(function () {
                $("#staticBackdrop").modal("show");
            }, 10000);
        
            // Show on button click
            $(".various").on("click", function () {
                $("#staticBackdrop").modal("show");
            });
        });    
        
    </script>
</body>
</html> 