<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="assets/images/favicon.webp">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css" />
    <link rel="stylesheet" href="https://cdn.rawgit.com/michalsnik/aos/1.0.1/dist/aos.css" />
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.0/dist/aos.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">
    <title>Webcore Digitals</title>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-5ZDDX47Q');</script>
    <!-- End Google Tag Manager -->
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5ZDDX47Q"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <header class="header-row" id="header-row">
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <!-- Logo -->
                <a class="navbar-brand" href="/">
                    <img src="assets/images/logo.png" alt="logo">
                </a>
                <!-- Navbar toggle -->
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <!-- Collapse -->
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <!-- Nav -->
                    <div class="navbar-nav mx-lg-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="/">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about-us">About Us</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="services" role="button">
                                Services
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="logo-and-branding">Logo and Brand Visibility</a></li>
                                <li><a class="dropdown-item" href="web-design">Web Design and Development</a></li>
                                <li><a class="dropdown-item" href="animation">Animation</a></li>
                                <li><a class="dropdown-item" href="mobile-application">Mobile Application Development</a></li>
                                <li><a class="dropdown-item" href="seo">Search Engine Optimization</a></li>
                                <li><a class="dropdown-item" href="illustration-and-art">Illustration and Art</a></li>
                                <li><a class="dropdown-item" href="content-marketing">Content Marketing</a></li>
                                <li><a class="dropdown-item" href="bpo-services">BPO Services</a></li>
                                <li><a class="dropdown-item" href="video-animation">Video Animation</a></li>
                                <li><a class="dropdown-item" href="digital-marketing">Digital Marketing</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="portfolio">Portfolio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="packages">Packages</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="blog">Blogs</a>
                        </li>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact-us">Contact Us</a>
                        </li>
                    </div>
                    <!-- Right navigation -->
                    <div class="d-flex align-items-lg-center">
                        <a href="javascript:;" class="btn btn-sm btn-primary w-full w-lg-auto w-btn various">Get a Quote</a>
                    </div>
                </div>
            </div>
        </nav>
    </header>    <section class="inner-banner-row">
        <div class="container">
            <div class="inner-banner-sec" data-aos="fade-up">
                <h1>Real Work. Real Results. Real <span>Impact.</span></h1>
                <p>From lightning-fast websites to scroll-stopping animations and powerful mobile apps, our portfolio showcases the kind of digital experiences we create. Every project is built with performance, creativity, and strategy in mind—designed to help our clients stand out, rank higher, and convert better.</p>
            </div>
        </div>
    </section>
    <section class="portfolio-page-row">
        <div class="container">
            <div class="inner-heading portfolio-head text-center" data-aos="slide-up">
                <img src="assets/images/portfolio-heading.png" alt="service heading">
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <div class="portfolio-sec" data-aos="fade-right">
                        <a data-fancybox="" href="assets/images/portfolio/website/01.webp" tabindex="0">
                            <figure>
                                <img src="assets/images/portfolio/website/01.webp" alt="portfolio image">
                            </figure>
                        </a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <div class="portfolio-sec" data-aos="fade-down">
                        <a data-fancybox="" href="assets/images/portfolio/website/02.webp" tabindex="0">
                            <figure>
                                <img src="assets/images/portfolio/website/02.webp" alt="portfolio image">
                            </figure>
                        </a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <div class="portfolio-sec" data-aos="fade-left">
                        <a data-fancybox="" href="assets/images/portfolio/website/03.webp" tabindex="0">
                            <figure>
                                <img src="assets/images/portfolio/website/03.webp" alt="portfolio image">
                            </figure>
                        </a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <div class="portfolio-sec" data-aos="fade-right">
                        <a data-fancybox="" href="assets/images/portfolio/website/04.webp" tabindex="0">
                            <figure>
                                <img src="assets/images/portfolio/website/04.webp" alt="portfolio image">
                            </figure>
                        </a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <div class="portfolio-sec" data-aos="fade-up">
                        <a data-fancybox="" href="assets/images/portfolio/website/05.webp" tabindex="0">
                            <figure>
                                <img src="assets/images/portfolio/website/05.webp" alt="portfolio image">
                            </figure>
                        </a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <div class="portfolio-sec" data-aos="fade-left">
                        <a data-fancybox="" href="assets/images/portfolio/website/06.webp" tabindex="0">
                            <figure>
                                <img src="assets/images/portfolio/website/06.webp" alt="portfolio image">
                            </figure>
                        </a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <div class="portfolio-sec" data-aos="fade-right">
                        <a data-fancybox="" href="assets/images/portfolio/website/07.webp" tabindex="0">
                            <figure>
                                <img src="assets/images/portfolio/website/07.webp" alt="portfolio image">
                            </figure>
                        </a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                    <div class="portfolio-sec" data-aos="fade-left">
                        <a data-fancybox="" href="assets/images/portfolio/website/08.webp" tabindex="0">
                            <figure>
                                <img src="assets/images/portfolio/website/08.webp" alt="portfolio image">
                            </figure>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="testimonials-row">
        <div class="container-fluid">
            <div class="w-head w-sec testi-head text-center" data-aos="slide-up">
                <h3>testimonials</h3>
                <img src="assets/images/review-heading.png" alt="service heading">
                <h2>What Our  <span>clients Love</span>  About Our Work?</h2>
            </div>
            <div class="testimonials-slider">
                <div id="testi-carousel" class="owl-carousel">
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-right">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>David R.</h4>
                                    <h5>Small Business Owner</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>Web Core Digital was amazing, transforming our old site to become fast, mobile and modern. Since release, we have had a 45 percent increase in leads.</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-down">
                            <div class="author-box">
                                <img src="assets/images/client-img2.png" alt="client images">
                                <div class="text">
                                    <h4>Mark P.</h4>
                                    <h5>Ecommerce Store Founder</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>I was also pleased with the speed at which their team worked on our site—improving speed and solving our technical SEO problems. Sales jumped within the first month!</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-left">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Carlos M.</h4>
                                    <h5>Consultant</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>Their UX improvements made a night-and-day difference. Our bounce rate dropped and visitors are staying longer. Highly recommend Web Core Digital.</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-right">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Jenna T.</h4>
                                    <h5>Startup Co-Founder</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>Web Core Digital did it all, from online purchasing a domain to a full brand launch. They discussed it all clearly and helped make it a stress-free process.</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-up">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Lauren B.</h4>
                                    <h5>Marketing Director</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>They helped us get on the first page of Google with few of our key terms. We're finally getting the traffic we deserve.</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-left">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Tom W.</h4>
                                    <h5>Freelance Designer</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>The outstanding characteristics were their personalization and swift interaction. They made my small project look at a big one.</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-right">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Williams K.</h4>
                                    <h5>Wellness Brand Owner</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>The Web Core Digital team completely transformed my Shopify store. It’s faster, cleaner, and getting more repeat customers.</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-left">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Josh H.</h4>
                                    <h5>Real Estate Broker</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>Our social media presence was flat. Web Core Digital worked with us and since then we have tripled our engagement and we are getting leads on Instagram!</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-right">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Rachel W.</h4>
                                    <h5>SEO Client</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>Their SEO services for small businesses gave us instant traction. Our leads doubled in under three months. The team at Web Core was super professional, and their communication stood out the most.</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-right">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Omar L.</h4>
                                    <h5>Business Owner</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>The team’s affordable logo design services gave us a professional brand identity that clients now recognise everywhere. The team was able to grasp what I had envisioned and went back and forth to really show that in the final outcome. </p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-right">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Kevin T.</h4>
                                    <h5>Small Business Owner</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>We wanted a website that was more than a brochure. Web Core Digitals gave us a fully optimised platform and management services, which were a true game-changer for our small business.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>    <footer class="footer-row">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-5">
                    <div class="footer-cont">
                        <img src="assets/images/footer-logo.png" alt="footer logo">
                        <p>Web Core Digital builds fast, high-performing websites that drive traffic and conversions.</p>
                        <a href="contact-us.php"><button class="btn btn-primary w-btn">book a call</button></a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-2">
                    <div class="footer-links">
                        <h6>Quick links</h6>
                        <ul>
                            <li><a href="/">Home</a></li>
                            <li><a href="about-us">About Us</a></li>
                            <li><a href="services">Services</a></li>
                            <li><a href="portfolio">Portfolio</a></li>
                            <li><a href="packages">Pricing</a></li>
                            <li><a href="contact-us">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-2">
                    <div class="footer-links">
                        <h6>SERVICES</h6>
                        <ul>
                            <li><a href="web-design">web design</a></li>
                            <li><a href="logo-and-branding">logo design</a></li>
                            <li><a href="mobile-application">app development </a></li>
                            <li><a href="animation">video animation</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                    <div class="footer-details">
                        <h6>Contact Info</h6>
                        <ul>
                            <li><a href="tel:315-753-8424">(315) 753-8424</a></li>
                            <li><a href="mailto:support@webcoredigitals.com">support@webcoredigitals.com</a></li>
                             <li><a href="javascript:;">85-49 Parsons Blvd Jamaica, NY 11432, USA</a></li> 
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-row">
            <div class="container-fluid">
                <div class="copyright-sec">
                    <p>Copyright © Webcore Digitals 2026. All rights reserved.</p>
                    <ul>
                        <li><a href="termsandconditions">Terms & Conditions</a></li>
                        <li><a href="privacy-policy">privacy policy</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="popup_form">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
                        <h3 class="title">Get Started</h3>
                        <form action="send_data.php" method="POST" name="popup-validate-form" id="popup_lead_data">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form_field">
                                        <input type="text" name="order_fullname" id="order_fullname" class="c_field" placeholder="Name*" required>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form_field">
                                        <input type="email" class="c_field" name="order_email" id="order_email" placeholder="Email Address*" required >
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form_field">
                                        <input type="text" name="number" id="phonePopup" class="c_field" placeholder="Phone Number*" required >
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form_field">
                                        <textarea class="c_field" name="order_description" id="order_description" rows="5" placeholder="Tell us about your website requirements"></textarea>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <button type="submit" class="btn btn-sm btn-primary w-btn">Get a Quote</button>
                                    <input type="hidden" name="cip" value="205.164.147.148">										
                                    <input type="hidden" id="location" name="locationURL" value="https://webcoredigitals.com/portfolio.php">
                                    <input type="hidden" name="order_package_name" value="Website Basic Package - $199" class="package_name" id="package_name">
                                    <input type="hidden" name="order-from" value="1">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.rawgit.com/michalsnik/aos/1.0.1/dist/aos.js"></script>
    <script src="https://unpkg.com/aos@2.3.0/dist/aos.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.0/js/fontawesome.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- Start of ultradigitalsolution Zendesk Widget script -->
    <script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=cb0f074a-fed2-429d-953d-ab53aee123aa"> </script>
    <!-- End of ultradigitalsolution Zendesk Widget script -->
        <script>
            zE(function() {
                $zopim(function() {
                    $zopim.livechat.setOnUnreadMsgs(unread);
            
                    function unread(number) {
                        if (number >= 1) {
                            $zopim.livechat.window.show();
                        }
                    }
                });
            });
        </script>
        <script>
            window.addEventListener("load", function () {
                setTimeout(function () {
                    if (window.zE) {
                        zE('webWidget', 'open');
                    }
                }, 30000); // 30 seconds = 30000 milliseconds
            });
        </script>
        <script>
         $(document).ready(function () {
            // Show after 5 seconds
            setTimeout(function () {
                $("#staticBackdrop").modal("show");
            }, 10000);
        
            // Show on button click
            $(".various").on("click", function () {
                $("#staticBackdrop").modal("show");
            });
        });    
        
    </script>
</body>
</html> 