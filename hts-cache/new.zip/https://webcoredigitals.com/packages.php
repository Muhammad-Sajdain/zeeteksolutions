<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="assets/images/favicon.webp">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css" />
    <link rel="stylesheet" href="https://cdn.rawgit.com/michalsnik/aos/1.0.1/dist/aos.css" />
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.0/dist/aos.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">
    <title>Webcore Digitals</title>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-5ZDDX47Q');</script>
    <!-- End Google Tag Manager -->
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5ZDDX47Q"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <header class="header-row" id="header-row">
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <!-- Logo -->
                <a class="navbar-brand" href="/">
                    <img src="assets/images/logo.png" alt="logo">
                </a>
                <!-- Navbar toggle -->
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <!-- Collapse -->
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <!-- Nav -->
                    <div class="navbar-nav mx-lg-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="/">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about-us">About Us</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="services" role="button">
                                Services
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="logo-and-branding">Logo and Brand Visibility</a></li>
                                <li><a class="dropdown-item" href="web-design">Web Design and Development</a></li>
                                <li><a class="dropdown-item" href="animation">Animation</a></li>
                                <li><a class="dropdown-item" href="mobile-application">Mobile Application Development</a></li>
                                <li><a class="dropdown-item" href="seo">Search Engine Optimization</a></li>
                                <li><a class="dropdown-item" href="illustration-and-art">Illustration and Art</a></li>
                                <li><a class="dropdown-item" href="content-marketing">Content Marketing</a></li>
                                <li><a class="dropdown-item" href="bpo-services">BPO Services</a></li>
                                <li><a class="dropdown-item" href="video-animation">Video Animation</a></li>
                                <li><a class="dropdown-item" href="digital-marketing">Digital Marketing</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="portfolio">Portfolio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="packages">Packages</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="blog">Blogs</a>
                        </li>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact-us">Contact Us</a>
                        </li>
                    </div>
                    <!-- Right navigation -->
                    <div class="d-flex align-items-lg-center">
                        <a href="javascript:;" class="btn btn-sm btn-primary w-full w-lg-auto w-btn various">Get a Quote</a>
                    </div>
                </div>
            </div>
        </nav>
    </header>    <section class="inner-banner-row">
        <div class="container">
            <div class="inner-banner-sec" data-aos="fade-up">
                <h1>Our <span>Pricing</span> Plans</h1>
                <p>We offer tailored pricing for businesses of all sizes—whether you're launching a new brand or optimizing an existing one. All packages come with expert support and scalable options.</p>
            </div>
        </div>
    </section>
    <section class="packages-row">
        <div class="container">
            <div class="inner-heading packages-head text-center" data-aos="slide-up">
                <img src="assets/images/pricing-heading.png" alt="service heading">
            </div>
            <div class="packages-tabs">
                <ul class="nav nav-pills justify-content-center" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-web-tab" data-bs-toggle="pill" data-bs-target="#pills-web" type="button" role="tab" aria-controls="pills-web" aria-selected="true">Web Design</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-ecommerce-tab" data-bs-toggle="pill" data-bs-target="#pills-ecommerce" type="button" role="tab" aria-controls="pills-ecommerce" aria-selected="false">E-Commerce Packages</button>
                    </li>
                </ul>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade active show" id="pills-web" role="tabpanel" aria-labelledby="pills-web-tab">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="packages-sec" data-aos="fade-right">
                                    <h2>Basic Website <br>Package</h2>
                                    <div class="pricebox"> <sup>$</sup>
							            <h3 class="animated fadeIn">199</h3><strike>$298<span>Only</span></strike> 
                                    </div>
                                    <ul class="scrollbar style-14">
                                        <li><strong>3</strong> Page Website</li>
                                        <li><strong>3</strong> Banner Design</li>
                                        <li><strong>1</strong> jQuery Slider Banner</li>
                                        <li><strong>FREE</strong> Google Friendly Sitemap</li>
                                        <li>Complete W3C Certified HTML</li>
                                        <li>48 to 72 hours TAT</li>
                                        <li><strong>100%</strong> Satisfaction Guarantee</li>
                                        <li><strong>100%</strong> Unique Design Guarantee</li>
                                        <li><strong>100%</strong> Money Back Guarantee *</li>
                                        <li>Mobile Responsive Will Be Additional <strong>$200*</strong></li>
                                        <li>CMS Will Be Additional <strong>$250*</strong></li>
                                    </ul>
                                    <div class="actions">
                                        <div class="col-md-6 col-xs-6">
                                            <a href="tel:315-753-8424" class="action-no clearfix pur"> <span><small>Speak with us</small> (315) 753-8424</span></a>
                                        </div>
                                        <div class="col-md-6 col-xs-6">
                                            <a href="javascript:void(Tawk_API.toggle())" class="chat" onclick="setButtonURL();"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
                                        </div>
                                    </div>
                                    <a name="199" data-title="Basic Webs Package - $149" href="javascript:;" class="w-btn activate_package various various">Start Project</a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="packages-sec" data-aos="fade-down">
                                    <h2>Startup Website <br>Package</h2>
                                     <div class="pricebox"> <sup>$</sup>
							            <h3 class="animated fadeIn">345</h3><strike>$690<span>Only</span></strike> 
                                    </div>
                                    <ul class="scrollbar style-14">
                                        <li><strong>5</strong> Stock Photos</li>
                                        <li><strong>5</strong> Page Website</li>
                                        <li><strong>3</strong> Banner Design</li>
                                        <li><strong>1</strong> jQuery Slider Banner</li>
                                        <li><strong>FREE</strong> Google Friendly Sitemap</li>
                                        <li>48 to 72 hours TAT</li>
                                        <li><strong>100%</strong> Satisfaction Guarantee</li>
                                        <li><strong>100%</strong> Unique Design Guarantee</li>
                                        <li><strong>100%</strong> Money Back Guarantee *</li>
                                        <li>Mobile Responsive will be Additional <strong>$200*</strong></li>
                                        <li>CMS will be Additional <strong>$250*</strong></li>
                                    </ul>
                                    <div class="actions">
                                        <div class="col-md-6 col-xs-6">
                                            <a href="tel:315-753-8424" class="action-no clearfix pur"> <span><small>Speak with us</small> (315) 753-8424</span></a>
                                        </div>
                                        <div class="col-md-6 col-xs-6">
                                            <a href="javascript:void(Tawk_API.toggle())" class="chat" onclick="setButtonURL();"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
                                        </div>
                                    </div>
                                    <a name="345" data-title="Startup Web Package - $345" href="javascript:;" class="w-btn activate_package various">Start Project</a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="packages-sec" data-aos="fade-left">
                                    <h2>Professional Website Package</h2>
                                     <div class="pricebox"> <sup>$</sup>
							            <h3 class="animated fadeIn">645</h3><strike>$1299<span>Only</span></strike> 
                                    </div>
                                    <ul class="scrollbar style-14">
                                        <li><strong>10</strong> Unique Pages Website</li>
                                        <li>CMS / Admin Panel Support</li>
                                        <li><strong>8</strong> Stock images</li>
                                        <li><strong>5</strong> Banner Designs</li>
                                        <li><strong>1</strong> jQuery Slider Banner</li>
                                        <li><strong>FREE</strong> Google Friendly Sitemap</li>
                                        <li>48 to 72 hours TAT</li>
                                        <li>Complete Deployment</li>
                                        <li><strong>100%</strong> Satisfaction Guarantee</li>
                                        <li><strong>100%</strong> Unique Design Guarantee</li>
                                        <li><strong>100%</strong> Money Back Guarantee *</li>
                                        <li>Mobile Responsive will be Additional <strong>$200*</strong></li>
                                    </ul>
                                    <div class="actions">
                                        <div class="col-md-6 col-xs-6">
                                            <a href="tel:315-753-8424" class="action-no clearfix pur"> <span><small>Speak with us</small> (315) 753-8424</span></a>
                                        </div>
                                        <div class="col-md-6 col-xs-6">
                                            <a href="javascript:void(Tawk_API.toggle())" class="chat" onclick="setButtonURL();"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
                                        </div>
                                    </div>
                                    <a name="645" data-title="Professional Website Package - $645" href="javascript:;" class="w-btn activate_package various">Start Project</a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="packages-sec" data-aos="fade-right">
                                    <h2>Elite Website <br>Package</h2>
                                     <div class="pricebox"> <sup>$</sup>
							            <h3 class="animated fadeIn">1249</h3><strike>$2498<span>Only</span></strike> 
                                    </div>
                                    <ul class="scrollbar style-14">
                                        <li>Upto <strong>15</strong> Unique Pages Website</li>
                                        <li>Conceptual and Dynamic Website</li>
                                        <li>Mobile Responsive</li>
                                        <li>Online Reservation/Appointment Tool (Optional)</li>
                                        <li>Online Payment Integration (Optional)</li>
                                        <li>Custom Forms</li>
                                        <li>Lead Capturing Forms (Optional)</li>
                                        <li>Striking Hover Effects</li>
                                        <li>Newsletter Subscription (Optional)</li>
                                        <li>Newsfeed Integration</li>
                                        <li>Social Media Integration</li>
                                        <li>Search Engine Submission</li>
                                        <li><strong>10</strong> Stock Photos</li>
                                        <li><strong>3</strong> Unique Banner Design</li>
                                        <li><strong>1</strong> jQuery Slider Banner</li>
                                        <li>48 to 72 hours TAT</li>
                                        <li>Complete Deployment</li>
                                        <li><strong>100%</strong> Satisfaction Guarantee</li>
                                        <li><strong>100%</strong> Unique Design Guarantee</li>
                                        <li><strong>100%</strong> Money Back Guarantee *</li>
                                    </ul>
                                    <div class="actions">
                                        <div class="col-md-6 col-xs-6">
                                            <a href="tel:315-753-8424" class="action-no clearfix pur"> <span><small>Speak with us</small> (315) 753-8424</span></a>
                                        </div>
                                        <div class="col-md-6 col-xs-6">
                                            <a href="javascript:void(Tawk_API.toggle())" class="chat" onclick="setButtonURL();"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
                                        </div>
                                    </div>
                                    <a name="1249" data-title="Elite Website Package - $1249" href="javascript:;" class="w-btn activate_package various">Start Project</a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="packages-sec" data-aos="fade-up">
                                    <h2>Corporate Website Package</h2>
                                     <div class="pricebox"> <sup>$</sup>
							            <h3 class="animated fadeIn">1945</h3><strike>$3890<span>Only</span></strike> 
                                    </div>
                                    <ul class="scrollbar style-14">
                                        <li> <strong>15</strong> to <strong>20</strong> Pages Website </li>
                                        <li> Custom Made, Interactive, Dynamic &amp; High End Design </li>
                                        <li>Custom WP (or) Custom PHP Development</li>
                                        <li><strong>1</strong> jQuery Slider Banner</li>
                                        <li>Up to <strong>10</strong> Custom Made Banner Designs</li>
                                        <li><strong>10</strong> Stock Images</li>
                                        <li>Unlimited Revisions</li>
                                        <li>Special Hoover Effects</li>
                                        <li>Content Management System (CMS)</li>
                                        <li>Online Appointment/Scheduling/Online Ordering Integration (Optional) </li>
                                        <li>Online Payment Integration (Optional)</li>
                                        <li>Multi Lingual (Optional)</li>
                                        <li>Custom Dynamic Forms (Optional)</li>
                                        <li>Signup Area (For Newsletters, Offers etc.)</li>
                                        <li>Search Bar</li>
                                        <li>Live Feeds of Social Networks integration (Optional)</li>
                                        <li>Mobile Responsive</li>
                                        <li>FREE <strong>5</strong> Years Domain Name</li>
                                        <li><strong>Free</strong> Google Friendly Sitemap</li>
                                        <li>Search Engine Submission</li>
                                        <li> Industry Specified Team of Expert Designers and Developers </li>
                                        <li>Complete Deployment</li>
                                        <li>Dedicated Accounts Manager</li>
                                        <li><strong>100%</strong> Ownership Rights</li>
                                        <li><strong>100%</strong> Satisfaction Guarantee</li>
                                        <li><strong>100%</strong> Unique Design Guarantee</li>
                                        <li><strong>100%</strong> Money Back Guarantee *</li>
                                    </ul>
                                    <div class="actions">
                                        <div class="col-md-6 col-xs-6">
                                            <a href="tel:315-753-8424" class="action-no clearfix pur"> <span><small>Speak with us</small> (315) 753-8424</span></a>
                                        </div>
                                        <div class="col-md-6 col-xs-6">
                                            <a href="javascript:void(Tawk_API.toggle())" class="chat" onclick="setButtonURL();"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
                                        </div>
                                    </div>
                                    <a name="1945" data-title="Corporate Website Package - $1945" href="javascript:;" class="w-btn activate_package various">Start Project</a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="packages-sec" data-aos="fade-left">
                                    <h2>Business Website Package</h2>
                                    <div class="pricebox"> <sup>$</sup>
							            <h3 class="animated fadeIn">2445</h3><strike>$4890<span>Only</span></strike> 
                                    </div>
                                    <ul class="scrollbar style-14">
                                        <li>15 to 20 Pages Website</li>
                                        <li>Custom Made, Interactive, Dynamic &amp; High End Design</li>
                                        <li>Custom WP (or) Custom PHP Development</li>
                                        <li>1 jQuery Slider Banner</li>
                                        <li>Up to 10 Custom Made Banner Designs</li>
                                        <li>10 Stock Images</li>
                                        <li>Unlimited Revisions</li>
                                        <li>Special Hoover Effects</li>
                                        <li>Content Management System (CMS)</li>
                                        <li>Online Appointment/Scheduling/Online Ordering Integration (Optional)</li>
                                        <li>Online Payment Integration (Optional)</li>
                                        <li>Multi Lingual (Optional)</li>
                                        <li>Custom Dynamic Forms (Optional)</li>
                                        <li>Signup Area (For Newsletters, Offers etc.)</li>
                                        <li>Search Bar</li>
                                        <li>Live Feeds of Social Networks integration (Optional)</li>
                                        <li>Mobile Responsive</li>
                                        <li>FREE 5 Years Domain Name</li>
                                        <li>Free Google Friendly Sitemap</li>
                                        <li>Search Engine Submission</li>
                                        <li>Complete W3C Certified HTML</li>
                                        <li>Industry Specified Team of Expert Designers and Developers</li>
                                        <li>Complete Deployment</li>
                                        <li>Dedicated Accounts Manager</li>
                                        <li>Facebook Page Design</li>
                                        <li>Twitter Page Design</li>
                                        <li>YouTube Page Design</li>
                                        <li>100% Ownership Rights</li>
                                        <li>100% Satisfaction Guarantee</li>
                                        <li>100% Unique Design Guarantee</li>
                                        <li>100% Money Back Guarantee *</li>
                                    </ul>
                                    <div class="actions">
                                        <div class="col-md-6 col-xs-6">
                                            <a href="tel:315-753-8424" class="action-no clearfix pur"> <span><small>Speak with us</small> (315) 753-8424</span></a>
                                        </div>
                                        <div class="col-md-6 col-xs-6">
                                            <a href="javascript:void(Tawk_API.toggle())" class="chat" onclick="setButtonURL();"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
                                        </div>
                                    </div>
                                    <a name="2445" data-title="Business Website Package - $2445" href="javascript:;" class="w-btn activate_package various">Start Project</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-ecommerce" role="tabpanel" aria-labelledby="pills-ecommerce-tab">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="packages-sec" data-aos="fade-right">
                                    <h2>Startup E-Commerce Package</h2>
                                    <div class="pricebox"> <sup>$</sup>
							            <h3 class="animated fadeIn">749</h3><strike>$1498<span>Only</span></strike> 
                                    </div>
                                    <ul class="scrollbar style-14">
                                        <li>Customized Design</li>
                                        <li>Up-To <strong>100</strong> Products</li>
                                        <li>Content Management System (CMS)</li>
                                        <li><strong>Mini</strong> Shopping Cart Integration</li>
                                        <li>Payment Module Integration</li>
                                        <li>Easy Product Search</li>
                                        <li>Dedicated Designer &amp; Developer</li>
                                        <li><strong>Unlimited</strong> Revisions</li>
                                        <li><strong>100%</strong> Satisfaction Guarantee</li>
                                        <li><strong>100%</strong> Unique Design Guarantee</li>
                                        <li><strong>100%</strong> Money Back Guarantee *</li>
                                    </ul>
                                    <div class="actions">
                                        <div class="col-md-6 col-xs-6">
                                            <a href="tel:315-753-8424" class="action-no clearfix pur"> <span><small>Speak with us</small> (315) 753-8424</span></a>
                                        </div>
                                        <div class="col-md-6 col-xs-6">
                                            <a href="javascript:void(Tawk_API.toggle())" class="chat" onclick="setButtonURL();"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
                                        </div>
                                    </div>
                                    <a name="749" data-title="Startup E-Commerce Package - $749" href="javascript:;" class="w-btn activate_package various">Start Project</a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="packages-sec" data-aos="fade-down">
                                    <h2>Professional E-Commerce Package</h2>
                                    <div class="pricebox"> <sup>$</sup>
							            <h3 class="animated fadeIn">1349</h3><strike>$2698<span>Only</span></strike> 
                                    </div>
                                    <ul class="scrollbar style-14">
                                        <li>Customized Design</li>
                                        <li>Up-To <strong>500</strong> Products</li>
                                        <li>Content Management System (CMS)</li>
                                        <li>Full Shopping Cart Integration</li>
                                        <li>Payment Module Integration</li>
                                        <li>Easy Product Search</li>
                                        <li>Product Reviews</li>
                                        <li><strong>5</strong> Promotional Banners</li>
                                        <li>Team Of Expert Designers &amp; Developers</li>
                                        <li>Unlimited Revisions</li>
                                        <li><strong>100%</strong> Satisfaction Guarantee</li>
                                        <li><strong>100%</strong> Unique Design Guarantee</li>
                                        <li><strong>100%</strong> Money Back Guarantee *</li>
                                    </ul>
                                    <div class="actions">
                                        <div class="col-md-6 col-xs-6">
                                            <a href="tel:315-753-8424" class="action-no clearfix pur"> <span><small>Speak with us</small> (315) 753-8424</span></a>
                                        </div>
                                        <div class="col-md-6 col-xs-6">
                                            <a href="javascript:void(Tawk_API.toggle())" class="chat" onclick="setButtonURL();"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
                                        </div>
                                    </div>
                                    <a name="1349" data-title="Professional E-Commerce Package - $1349" href="javascript:;" class="w-btn activate_package various">Start Project</a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="packages-sec" data-aos="fade-left">
                                    <h2>Elite E-Commerce Package</h2>
                                    <div class="pricebox"> <sup>$</sup>
							            <h3 class="animated fadeIn">2449</h3><strike>$4898<span>Only</span></strike> 
                                    </div>
                                    <ul class="scrollbar style-14">
                                        <li>Unlimited Pages Website with Unique Design</li>
                                        <li><strong>5</strong>Custom Logo Design</li>
                                        <li>CMS / Backend Adminstrative System</li>
                                        <li>Unlimited Products with Unlimited Categories</li>
                                        <li><strong>FREE</strong> Unlimited Revisions</li>
                                        <li>Custom Shopping Cart Integration</li>
                                        <li>Multiple Payment Module Integration</li>
                                        <li>Multiple Shipping Module Integration</li>
                                        <li>Product Ratings &amp; Reviews</li>
                                        <li>Sales &amp; Inventory Management System</li>
                                        <li>Multiple Currency Support</li>
                                        <li>Customer Login Area (Sign-Up &amp; Sign-In)</li>
                                        <li>Mobile Responsive</li>
                                        <li>Social Media Designs (Facebook, Twitter, Youtube)</li>
                                        <li>Dedicated Team of Expert Designers &amp; Developers</li>
                                        <li>Dedicated Project Manager</li>
                                        <li>News Letter Subscription</li>
                                        <li><strong>100%</strong> Satisfaction Guarantee</li>
                                        <li><strong>100%</strong> Money Back Guarantee *</li>
                                    </ul>
                                    <div class="actions">
                                        <div class="col-md-6 col-xs-6">
                                            <a href="tel:315-753-8424" class="action-no clearfix pur"> <span><small>Speak with us</small> (315) 753-8424</span></a>
                                        </div>
                                        <div class="col-md-6 col-xs-6">
                                            <a href="javascript:void(Tawk_API.toggle())" class="chat" onclick="setButtonURL();"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
                                        </div>
                                    </div>
                                    <a name="2449" data-title="Elite E-Commerce Package - $2449" href="javascript:;" class="w-btn activate_package various">Start Project</a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="packages-sec" data-aos="fade-right">
                                    <h2>Business E-Commerce Package</h2>
                                    <div class="pricebox"> <sup>$</sup>
							            <h3 class="animated fadeIn">4994</h3><strike>$9988<span>Only</span></strike> 
                                    </div>
                                    <ul class="scrollbar style-14">
                                        <li>Complete Custom Design &amp; Development</li>
                                        <li>Unique, User Friendly, Interactive, Dynamic, High End UI Design</li>
                                        <li>Unlimited Banner Designs</li>
                                        <li>Interactive Sliding Banners</li>
                                        <li>Special Hover Effects</li>
                                        <li>Customized Contact us Form</li>
                                        <li>Multiple Filtration Option (Search by Age, Experience, Talent, Industry etc)</li>
                                        <li>Profile Comparison (As per Category)</li>
                                        <li>File Converter</li>
                                        <li>Custom Video Functionality</li>
                                        <li>Multiple File format Uploading</li>
                                        <li>User Signup Area ( Talent )</li>
                                        <li>User Signup Area ( Casting )</li>
                                        <li>User Signup Area ( Agency )</li>
                                        <li>Client/User Dashboard Area</li>
                                        <li>Vendor / Agency Dashboard Area</li>
                                        <li>Custom Coding and Development</li>
                                        <li>Content Management System (Custom)</li>
                                        <li>Online Appointment/Scheduling integration (Optional)</li>
                                        <li>Online Payment Integration</li>
                                        <li>Invoicing System</li>
                                        <li>Automated Email Notifications</li>
                                        <li>Multi Lingual (Optional)</li>
                                        <li>Custom Dynamic Forms</li>
                                        <li>Complete Database Creation</li>
                                        <li>3rd Party Links integration (Instagram, IMDB etc )</li>
                                        <li>Signup Automated Email Authentication</li>
                                        <li>Signup Area (For Newsletters, Offers etc.)</li>
                                        <li>Search Bar for Easy Search</li>
                                        <li>Live Feeds of Social Networks integration (Optional)</li>
                                        <li>Search Engine Submission</li>
                                        <li>SEO friendly</li>
                                        <li>Mobile Responsive</li>
                                        <li>Master Admin Panel</li>
                                        <li>SSL Certification ( to make the website and it’s informative secured )</li>
                                        <li>1 Year Free Hosting</li>
                                        <li>6 Months of Free Maintenance</li>
                                        <li>Award Winning Team of Expert Designers and Developers</li>
                                        <li>Complete Deployment</li>
                                        <li>Complete W3C Validation</li>
                                        <li>Dedicated Team of Designers and Developers</li>
                                    </ul>
                                    <div class="actions">
                                        <div class="col-md-6 col-xs-6">
                                            <a href="tel:315-753-8424" class="action-no clearfix pur"> <span><small>Speak with us</small> (315) 753-8424</span></a>
                                        </div>
                                        <div class="col-md-6 col-xs-6">
                                            <a href="javascript:void(Tawk_API.toggle())" class="chat" onclick="setButtonURL();"> <span><small>Want to discuss?</small> Live Chat Now</span></a>
                                        </div>
                                    </div>
                                    <a name="4994" data-title="Business E-Commerce Package - $4994" href="javascript:;" class="w-btn activate_package various">Start Project</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="choose-row packages-choose-row">
        <div class="container-fluid">
            <div class="w-head choose-head">
                <h3>Why Choose Us</h3>
                <h2>web core digital</h2>
            </div>
            <div class="row align-items-center">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-5">
                    <div class="w-sec choose-sec">
                        <h2>Affordable Pricing. Exceptional Quality. Real <span>Results.</span></h2>
                        <p>We think that great solutions in the digital realm need not be expensive at Web Core Digital. That is why our prices are open, fluid, and value-stuffed. Whether you are an emerging company or expanding brand, we can support your business to grow using beautiful websites, zippy apps, strategic search engine optimization, and creative content, all without burning holes in your pocket!</p>
                        <a href="javascript:;"><button class="btn btn-primary w-btn">get started</button></a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-7">
                    <div class="choose-lft-sec">
                        <img src="assets/images/choose-package-img.png" alt="choose image">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="milestone-row">
        <div class="container-fluid">
            <div class="milestone-inner-row">
                <h3>have experience of satisfied students</h3>
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                        <div class="milestone-sec" data-aos="fade-right">
                            <h2 id="number1">500</h2>
                            <p>AI-Powered Social Media Insights Shared</p>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                        <div class="milestone-sec" data-aos="fade-down">
                            <h2 id="number1">1</h2>
                            <p>Social Media Professionals</p>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
                        <div class="milestone-sec" data-aos="fade-left">
                            <h2 id="number1">1</h2>
                            <p> Brands & Creators Leveraging Our Resources</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="portfolio-row">
        <div class="container-fluid">
            <div class="portfolio-head text-center" data-aos="fade-up">
                <h3>our portfolio</h3>
                <h2>portfolio</h2>
            </div>
            <div class="portfolio-tabs">
                <ul class="nav nav-pills justify-content-center" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-web-tab" data-bs-toggle="pill" data-bs-target="#pills-web" type="button" role="tab" aria-controls="pills-web" aria-selected="false">Web Design</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-logo-tab" data-bs-toggle="pill" data-bs-target="#pills-logo" type="button" role="tab" aria-controls="pills-logo" aria-selected="false">Logo & Brand Identity</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-video-tab" data-bs-toggle="pill" data-bs-target="#pills-video" type="button" role="tab" aria-controls="pills-video" aria-selected="false">Video Animation</button>
                    </li>
                </ul>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-web" role="tabpanel" aria-labelledby="pills-web-tab">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-right">
                                    <a data-fancybox="" href="assets/images/portfolio/website/01.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/01.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-down">
                                    <a data-fancybox="" href="assets/images/portfolio/website/02.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/02.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-left">
                                    <a data-fancybox="" href="assets/images/portfolio/website/03.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/03.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-right">
                                    <a data-fancybox="" href="assets/images/portfolio/website/04.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/04.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-up">
                                    <a data-fancybox="" href="assets/images/portfolio/website/05.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/05.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-left">
                                    <a data-fancybox="" href="assets/images/portfolio/website/06.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/06.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-right">
                                    <a data-fancybox="" href="assets/images/portfolio/website/07.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/07.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-left">
                                    <a data-fancybox="" href="assets/images/portfolio/website/08.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/website/08.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                        </div>                    </div>
                    <div class="tab-pane fade" id="pills-logo" role="tabpanel" aria-labelledby="pills-logo-tab">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-right">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/01.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/01.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-down">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/logo-portfolio1.jpg" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/logo-portfolio1.jpg" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-left">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/03.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/03.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-right">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/logo-portfolio2.jpg" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/logo-portfolio2.jpg" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-up">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/logo-portfolio3.jpg" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/logo-portfolio3.jpg" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-left">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/logo-portfolio4.jpg" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/logo-portfolio4.jpg" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-right">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/07.webp" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/07.webp" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3">
                                <div class="portfolio-sec" data-aos="fade-left">
                                    <a data-fancybox="" href="assets/images/portfolio/logo/logo-portfolio5.jpg" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/logo/logo-portfolio5.jpg" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                        </div>                    </div>
                    <div class="tab-pane fade" id="pills-video" role="tabpanel" aria-labelledby="pills-video-tab">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="portfolio-sec" data-aos="fade-right">
                                    <a data-fancybox="" href="assets/images/portfolio/video/video1.mp4" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/video/video1-thumb.jpg" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="portfolio-sec" data-aos="fade-down">
                                    <a data-fancybox="" href="assets/images/portfolio/video/video2.mp4" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/video/video2-thumb.jpg" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
                                <div class="portfolio-sec" data-aos="fade-left">
                                    <a data-fancybox="" href="assets/images/portfolio/video/video3.mp4" tabindex="0">
                                        <figure>
                                            <img src="assets/images/portfolio/video/video3-thumb.jpg" alt="portfolio image">
                                        </figure>
                                    </a>
                                </div>
                            </div>
                        </div>                    </div>
                </div>
            </div>
            <div class="video-btn">
                <a href="portfolio.php"><button class="btn btn-primary w-btn">learn more</button></a>
                <a href="javascript:;"><button class="btn btn-primary w-btn w-btn2"><i class="fa-regular fa-envelope"></i> live chat</button></a>
            </div>
        </div>
    </section>
    
    <section class="testimonials-row">
        <div class="container-fluid">
            <div class="w-head w-sec testi-head text-center" data-aos="slide-up">
                <h3>testimonials</h3>
                <img src="assets/images/review-heading.png" alt="service heading">
                <h2>What Our  <span>clients Love</span>  About Our Work?</h2>
            </div>
            <div class="testimonials-slider">
                <div id="testi-carousel" class="owl-carousel">
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-right">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>David R.</h4>
                                    <h5>Small Business Owner</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>Web Core Digital was amazing, transforming our old site to become fast, mobile and modern. Since release, we have had a 45 percent increase in leads.</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-down">
                            <div class="author-box">
                                <img src="assets/images/client-img2.png" alt="client images">
                                <div class="text">
                                    <h4>Mark P.</h4>
                                    <h5>Ecommerce Store Founder</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>I was also pleased with the speed at which their team worked on our site—improving speed and solving our technical SEO problems. Sales jumped within the first month!</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-left">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Carlos M.</h4>
                                    <h5>Consultant</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>Their UX improvements made a night-and-day difference. Our bounce rate dropped and visitors are staying longer. Highly recommend Web Core Digital.</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-right">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Jenna T.</h4>
                                    <h5>Startup Co-Founder</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>Web Core Digital did it all, from online purchasing a domain to a full brand launch. They discussed it all clearly and helped make it a stress-free process.</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-up">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Lauren B.</h4>
                                    <h5>Marketing Director</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>They helped us get on the first page of Google with few of our key terms. We're finally getting the traffic we deserve.</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-left">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Tom W.</h4>
                                    <h5>Freelance Designer</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>The outstanding characteristics were their personalization and swift interaction. They made my small project look at a big one.</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-right">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Williams K.</h4>
                                    <h5>Wellness Brand Owner</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>The Web Core Digital team completely transformed my Shopify store. It’s faster, cleaner, and getting more repeat customers.</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-left">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Josh H.</h4>
                                    <h5>Real Estate Broker</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>Our social media presence was flat. Web Core Digital worked with us and since then we have tripled our engagement and we are getting leads on Instagram!</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-right">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Rachel W.</h4>
                                    <h5>SEO Client</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>Their SEO services for small businesses gave us instant traction. Our leads doubled in under three months. The team at Web Core was super professional, and their communication stood out the most.</p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-right">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Omar L.</h4>
                                    <h5>Business Owner</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>The team’s affordable logo design services gave us a professional brand identity that clients now recognise everywhere. The team was able to grasp what I had envisioned and went back and forth to really show that in the final outcome. </p>
                        </div>
                    </div>
                    <div class="item">
                        <div class="testimonials-sec" data-aos="fade-right">
                            <div class="author-box">
                                <img src="assets/images/client-img1.png" alt="client images">
                                <div class="text">
                                    <h4>Kevin T.</h4>
                                    <h5>Small Business Owner</h5>
                                    <ul>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                        <li><i class="fa-solid fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                            <p>We wanted a website that was more than a brochure. Web Core Digitals gave us a fully optimised platform and management services, which were a true game-changer for our small business.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>    <footer class="footer-row">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-5">
                    <div class="footer-cont">
                        <img src="assets/images/footer-logo.png" alt="footer logo">
                        <p>Web Core Digital builds fast, high-performing websites that drive traffic and conversions.</p>
                        <a href="contact-us.php"><button class="btn btn-primary w-btn">book a call</button></a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-2">
                    <div class="footer-links">
                        <h6>Quick links</h6>
                        <ul>
                            <li><a href="/">Home</a></li>
                            <li><a href="about-us">About Us</a></li>
                            <li><a href="services">Services</a></li>
                            <li><a href="portfolio">Portfolio</a></li>
                            <li><a href="packages">Pricing</a></li>
                            <li><a href="contact-us">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-2">
                    <div class="footer-links">
                        <h6>SERVICES</h6>
                        <ul>
                            <li><a href="web-design">web design</a></li>
                            <li><a href="logo-and-branding">logo design</a></li>
                            <li><a href="mobile-application">app development </a></li>
                            <li><a href="animation">video animation</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">
                    <div class="footer-details">
                        <h6>Contact Info</h6>
                        <ul>
                            <li><a href="tel:315-753-8424">(315) 753-8424</a></li>
                            <li><a href="mailto:support@webcoredigitals.com">support@webcoredigitals.com</a></li>
                             <li><a href="javascript:;">85-49 Parsons Blvd Jamaica, NY 11432, USA</a></li> 
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-row">
            <div class="container-fluid">
                <div class="copyright-sec">
                    <p>Copyright © Webcore Digitals 2026. All rights reserved.</p>
                    <ul>
                        <li><a href="termsandconditions">Terms & Conditions</a></li>
                        <li><a href="privacy-policy">privacy policy</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="popup_form">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
                        <h3 class="title">Get Started</h3>
                        <form action="send_data.php" method="POST" name="popup-validate-form" id="popup_lead_data">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form_field">
                                        <input type="text" name="order_fullname" id="order_fullname" class="c_field" placeholder="Name*" required>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form_field">
                                        <input type="email" class="c_field" name="order_email" id="order_email" placeholder="Email Address*" required >
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form_field">
                                        <input type="text" name="number" id="phonePopup" class="c_field" placeholder="Phone Number*" required >
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form_field">
                                        <textarea class="c_field" name="order_description" id="order_description" rows="5" placeholder="Tell us about your website requirements"></textarea>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <button type="submit" class="btn btn-sm btn-primary w-btn">Get a Quote</button>
                                    <input type="hidden" name="cip" value="205.164.147.148">										
                                    <input type="hidden" id="location" name="locationURL" value="https://webcoredigitals.com/packages.php">
                                    <input type="hidden" name="order_package_name" value="Website Basic Package - $199" class="package_name" id="package_name">
                                    <input type="hidden" name="order-from" value="1">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.rawgit.com/michalsnik/aos/1.0.1/dist/aos.js"></script>
    <script src="https://unpkg.com/aos@2.3.0/dist/aos.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.0/js/fontawesome.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- Start of ultradigitalsolution Zendesk Widget script -->
    <script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=cb0f074a-fed2-429d-953d-ab53aee123aa"> </script>
    <!-- End of ultradigitalsolution Zendesk Widget script -->
        <script>
            zE(function() {
                $zopim(function() {
                    $zopim.livechat.setOnUnreadMsgs(unread);
            
                    function unread(number) {
                        if (number >= 1) {
                            $zopim.livechat.window.show();
                        }
                    }
                });
            });
        </script>
        <script>
            window.addEventListener("load", function () {
                setTimeout(function () {
                    if (window.zE) {
                        zE('webWidget', 'open');
                    }
                }, 30000); // 30 seconds = 30000 milliseconds
            });
        </script>
        <script>
         $(document).ready(function () {
            // Show after 5 seconds
            setTimeout(function () {
                $("#staticBackdrop").modal("show");
            }, 10000);
        
            // Show on button click
            $(".various").on("click", function () {
                $("#staticBackdrop").modal("show");
            });
        });    
        
    </script>
</body>
</html> 